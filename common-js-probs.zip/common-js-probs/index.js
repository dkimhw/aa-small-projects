
// Your code here
import { message1, message2, message3 } from './messages/index.js';
import sayHelloTo from './send-messages/say-hello-to.js';
import giveMessageToMrsPotato from './send-messages/give-message-to-mrs-potato.js';
/****************************************************************************/
/******************* DO NOT EDIT CODE BELOW THIS LINE ***********************/
let msg1 = message1;
let msg2 = message2;
let msg3 = message3;
sayHelloTo("Mr. Potato");
giveMessageToMrsPotato(msg1);
giveMessageToMrsPotato(msg2);
giveMessageToMrsPotato(msg3);
