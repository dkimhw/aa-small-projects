import helloMessage from "./hello-message.js";

function sayMessage(message) {
  console.log(`"${message}"`)
}

sayMessage(helloMessage);


export default sayMessage;
