const helloMessage = "Greetings! Let us begin!";


export default helloMessage;
